package com.sergiotrapiello.cursotesting.application.controller;

/**
 * Interface de marca para definir un controller
 */
public interface Controller {

}
